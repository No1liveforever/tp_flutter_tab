package com.example.tp_tab

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
