import 'package:flutter/material.dart';

class AlaeSpecializationScreen extends StatefulWidget {
  const AlaeSpecializationScreen({Key? key}) : super(key: key);

  @override
  State<AlaeSpecializationScreen> createState() => _AlaeSpecializationScreenState();
}

class _AlaeSpecializationScreenState extends State<AlaeSpecializationScreen> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
