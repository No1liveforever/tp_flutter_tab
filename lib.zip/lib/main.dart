import 'package:flutter/material.dart';
import 'abdellah_expertise_screen.dart';
import 'oumaima_professional_screen.dart';
import 'alae_specialization_screen.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: AbdellahExpertiseScreen(),
    );
  }
}
