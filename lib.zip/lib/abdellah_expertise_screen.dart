import 'package:flutter/material.dart';

class AbdellahExpertiseScreen extends StatefulWidget {
  const AbdellahExpertiseScreen({Key? key}) : super(key: key);

  @override
  State<AbdellahExpertiseScreen> createState() => _AbdellahExpertiseScreenState();
}

class _AbdellahExpertiseScreenState extends State<AbdellahExpertiseScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Abdellah's Expertise", textAlign: TextAlign.center)),
      body: Column(
        children: [
          Text("This is where the information about Abdellah's expertise goes."),
        ],
      ),
    );
  }
}
