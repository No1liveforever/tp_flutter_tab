import 'package:flutter/material.dart';

class OumaimaProfessionalScreen extends StatefulWidget {
  const OumaimaProfessionalScreen({Key? key}) : super(key: key);

  @override
  State<OumaimaProfessionalScreen> createState() => _OumaimaProfessionalScreenState();
}

class _OumaimaProfessionalScreenState extends State<OumaimaProfessionalScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Oumaima's Professional Background", textAlign: TextAlign.center)),
      body: Column(
        children: [
          Text("This is where the information about Oumaima's professional background goes."),
        ],
      ),
    );
  }
}
